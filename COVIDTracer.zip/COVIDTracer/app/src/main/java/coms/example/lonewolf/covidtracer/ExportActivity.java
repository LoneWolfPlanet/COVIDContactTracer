package coms.example.lonewolf.covidtracer;

import android.app.DatePickerDialog;
import android.content.Context;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;import android.content.Intent;import android.content.Intent;
import java.security.PublicKey;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import android.content.Intent;
import java.io.File;
import java.io.FileWriter;
import java.util.Date;
import java.util.List;
import android.os.Environment;
public class ExportActivity extends AppCompatActivity {
    final Context context = this;
    DatabaseHandler database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export);

        database = new DatabaseHandler(context);
        MasterData master =  database.getMasterData();

        final EditText etFromDate = (EditText)findViewById(R.id.editTextFromDate);
        String default_date = "";
        if(!master.getStartDateTime().isEmpty())
        {
            default_date = master.getStartDateTime();
        }
        else {

            Calendar calendar  = Calendar.getInstance();
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int month = calendar.get(Calendar.MONTH);
            int year = calendar.get(Calendar.YEAR);
            etFromDate.setText( Integer.toString(day)+ "-" + (Integer.toString(month) + 1) + "-" + Integer.toString(year));
        }
        etFromDate.setInputType(InputType.TYPE_NULL);
        etFromDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar  = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                DatePickerDialog picker = new DatePickerDialog(ExportActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                                etFromDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });

        final EditText etToDate = (EditText)findViewById(R.id.editTextToDate);
        etToDate.setInputType(InputType.TYPE_NULL);
        Date current = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate = df.format(current);
        etToDate.setText(formattedDate);

        etToDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar  = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                DatePickerDialog picker = new DatePickerDialog(ExportActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                                etToDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });

        final Button btnConfirm = (Button)findViewById(R.id.btn_confirm);
        btnConfirm.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {

                database = new DatabaseHandler(context);
                List<DeviceInfo> deviceInfoList= database.getAllData();

                CreateCSV(deviceInfoList);
                String display = "";
                for(DeviceInfo info : deviceInfoList )
                {
                    display = display + "Date: " + info.getDateTime();
                    display = display + "\n";
                    display = display + info.getCPNumber();
                    display = display + "\n\n";
                }
                ExportDialog exportDialog = new ExportDialog();
                exportDialog.setDisplay(display);
                exportDialog.setContext(context);
                exportDialog.show(getSupportFragmentManager(), "ExportDialog");
            }
        });

        final Button btnCancel =(Button)findViewById(R.id.btn_cancel);
        btnCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent main =new Intent(context, MainActivity.class);
                startActivity(main);
            }
        });

    }

    private void CreateCSV(List<DeviceInfo> deviceInfoList)
    {
        String formattedData = "";
        String separator = ",";
        formattedData = formattedData + "DeviceName " +separator + "Date" + separator +
                "Mac Address" + separator +  "Location" + separator + "\n" ;
        for(DeviceInfo device : deviceInfoList)
        {
            formattedData = formattedData + device.getCPNumber() + separator;
            formattedData  = formattedData + device.getDateTime() + separator;
            formattedData = formattedData + device.getMacAddress() + separator;
            formattedData = formattedData + device.getLocation()  + separator +  "\n";
        }

        try{
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            String storage = dir + File.separator + "history.csv";
            File file = new File(storage);
            if(!file.exists())
            {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(storage);
            fw.append(formattedData);
            fw.close();
        }
        catch (Exception e){
            int i = 1;
        }

    }
}
