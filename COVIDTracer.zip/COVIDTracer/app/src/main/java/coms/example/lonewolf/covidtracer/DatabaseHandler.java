package coms.example.lonewolf.covidtracer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import android.database.sqlite.*;
import android.support.annotation.NonNull;
import java.io.*;
import java.util.ListIterator;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.content.Context;

public class DatabaseHandler  extends SQLiteOpenHelper{

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "history.db";
    private static final String TABLE_HISTORY = "tDeviceInfo";
    private static final String TABLE_MASTER = "tMaster";
    private static final String KEY_ID = "id";
    private static final String KEY_DEVICE_NAME = "deviceName";
    private static final String KEY_DATE_TIME = "dateTime";
    private static final String KEY_DATE_TIME_START = "startDateTime";
    private static final String KEY_LOCATION = "location";
    private static final String KEY_MAC_ADDRESS = "macAddress";
    private static SQLiteDatabase mydatabase;

    public static void SetDatabase(SQLiteDatabase database)
    {
       mydatabase = database;
    }
    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        onCreate(mydatabase);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_CONTACTS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_HISTORY + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_DEVICE_NAME + " TEXT,"
                + KEY_DATE_TIME  + " TEXT," + KEY_LOCATION  + " TEXT," + KEY_MAC_ADDRESS + " TEXT" +")";
        db.execSQL(CREATE_CONTACTS_TABLE);

        String CREATE_MASTER_TABLE = "CREATE TABLE IF NOT EXISTS "+ TABLE_MASTER + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_DEVICE_NAME + " TEXT,"
                + KEY_DATE_TIME_START  + " TEXT " + ")";

        db.execSQL(CREATE_MASTER_TABLE);
    }

    public MasterData getMasterData()
    {
        MasterData result = new MasterData();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_MASTER;
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.getCount() > 1) {
            while (cursor.moveToNext()) {

                result.deviceName = (cursor.getString(1));
                result.startDateTime = (cursor.getString(2));
                break;
            }
        }
        return  result;
    }

    public void setTableMaster(MasterData data)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_DEVICE_NAME, data.getDeviceName());
        values.put(KEY_DATE_TIME_START, data.getStartDateTime());
        db.insert(TABLE_MASTER, null, values);
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HISTORY);
        // Create tables again
        onCreate(db);
    }

    public void insertRow(DeviceInfo info){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_DEVICE_NAME, info.getCPNumber());
        values.put(KEY_DATE_TIME, info.getDateTime());
        values.put(KEY_LOCATION, info.getLocation());
        values.put(KEY_MAC_ADDRESS, info.getMacAddress());
        db.insert(TABLE_HISTORY, null, values);
        db.close();
    }

     public boolean checkDeviceName(String number)
     {
         boolean result = false;
         SQLiteDatabase db = this.getReadableDatabase();
         String selectQuery = "SELECT *  FROM " +  TABLE_HISTORY ;

         try{
             Cursor cursor = db.rawQuery(selectQuery, null);
             if (cursor.getCount() > 1)
             {
                 while (cursor.moveToNext()) {
                     String date = cursor.getString(2);
                     String num = cursor.getString(1);
                     if (number.equals(num))
                     {
                         Date current = Calendar.getInstance().getTime();
                         SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                         String formattedDate = df.format(current);
                         if (date.equals(formattedDate))
                         {
                             result = true;
                             break;
                         }
                     }

                 }

             }
         }
         catch (Exception e) {
         }

         return result;
     }
    public List<DeviceInfo> getAllData()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        List<DeviceInfo> deviceInfoList = new ArrayList<DeviceInfo>() ;
        String selectQuery = "SELECT  * FROM " + TABLE_HISTORY;
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                DeviceInfo info = new DeviceInfo();
                info.setCPNumber(cursor.getString(1));
                info.setDateTime(cursor.getString(2));
                info.setLocation(cursor.getString(3));
                info.setMacAddress(cursor.getString(4));

                deviceInfoList.add(info);
            } while (cursor.moveToNext());
        }
        return deviceInfoList;
    }
}
