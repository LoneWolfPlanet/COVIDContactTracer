package coms.example.lonewolf.covidtracer;

import android.app.AlertDialog;
import android.content.Context;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.*;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.widget.TextView;
import android.content.DialogInterface;
import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ScanActivity extends AppCompatActivity {

     int REQUEST_ENABLE_BT = 1;
     String cpNumber;
    TextView nearbyView;
    BluetoothAdapter bluetoothAdapter;
    DatabaseHandler database;
    final Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
        Intent intent = getIntent();
        this.cpNumber = intent.getStringExtra("number");
        this.nearbyView = (TextView) findViewById(R.id.tv_nearby);

        database = new DatabaseHandler(context);
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(receiver, filter);
        startBluetooth();
    }
    // Create a BroadcastReceiver for ACTION_FOUND.
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address
                deviceName = deviceName + "\n";
                nearbyView.append(deviceName);
                nearbyView.invalidate();
                if(!database.checkDeviceName(device.getName()))
                {
                    Date current = Calendar.getInstance().getTime();
                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                    String formattedDate = df.format(current);
                    DeviceInfo info = new DeviceInfo();
                    info.setDateTime(formattedDate);
                    info.setCPNumber(device.getName());
                    info.setMacAddress(deviceHardwareAddress);
                    database.insertRow(info);
                }
            }
        }
    };
    public void startBluetooth()
    {
        this.bluetoothAdapter= BluetoothAdapter.getDefaultAdapter();
        if (this.bluetoothAdapter != null) {
            if(!this.bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            this.bluetoothAdapter.setName(this.cpNumber);
            this.bluetoothAdapter.startDiscovery();
        }
    }

    @Override
    public void onBackPressed() {
        Intent main =new Intent(context, MainActivity.class);
        startActivity(main);
    }
}
