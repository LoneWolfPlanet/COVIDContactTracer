package coms.example.lonewolf.covidtracer;

import android.support.v4.view.ViewPager;

import java.util.Date;

public class DeviceInfo {
    public int id;
    public String cpNumber;
    public String macAddress;
    public String location;
    public String dateTime;

    public DeviceInfo(){
        id = 0;
        macAddress = "";
        location = "";
        dateTime = "";
        cpNumber = "";

    }

    public void setId(int id)
    {
        this.id = id;
    }

    public void setMacAddress(String mac_address)
    {
        this.macAddress= macAddress;
    }

    public void setCPNumber(String cp_number)
    {
        this.cpNumber = cp_number;
    }

    public void setDateTime(String date_time)
    {
        this.dateTime = date_time;
    }

    public void setLocation(String location)
    {
       this.location = location;
    }

    public String getMacAddress(){
        return this.macAddress;
    }

    public String getCPNumber(){
        return this.cpNumber;
    }

    public String getDateTime(){
        return this.dateTime;
    }

    public String getLocation(){
        return this.location;
    }


}
