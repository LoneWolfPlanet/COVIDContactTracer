package coms.example.lonewolf.covidtracer;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class ScanDialog extends DialogFragment {


     Context context;
     String startDate ;
    public void setContext(Context context)
    {
        this.context = context;
    }
     View main_view;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       main_view = inflater.inflate(R.layout.fragment_scan_dialog, container, false);

        startDate = "";
       DatabaseHandler handler = new DatabaseHandler(context);
       MasterData master = handler.getMasterData();

       if(!master.getDeviceName().isEmpty())
       {
            EditText textEdit = (EditText) main_view.findViewById(R.id.editTextCPNumber);
           textEdit.setText(master.getDeviceName());
           startDate = master.getStartDateTime();
       }

        final Button confirmButton = (Button)main_view.findViewById(R.id.btn_continue);
       confirmButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               final EditText textEdit = (EditText) main_view.findViewById(R.id.editTextCPNumber);
               final String cp_number = textEdit.getText().toString();
               DatabaseHandler handler = new DatabaseHandler(context);
               MasterData data = new MasterData();
               data.deviceName = cp_number;
               if(!startDate.isEmpty())
               {

                   data.startDateTime = startDate;
               }
               else {
                  data.setStartDateTime();
               }
               handler.setTableMaster(data);
               Intent scan =new Intent(context, ScanActivity.class);
               scan.putExtra("number", cp_number);
               startActivity(scan);
           }
       });

       return  main_view;
    }





}
