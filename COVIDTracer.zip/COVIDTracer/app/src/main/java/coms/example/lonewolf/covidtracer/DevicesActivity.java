package coms.example.lonewolf.covidtracer;

import android.bluetooth.BluetoothClass;
import android.content.Context;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DevicesActivity extends AppCompatActivity {

    DatabaseHandler database;
    final Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_devices);
        List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();

        database = new DatabaseHandler(context);
        List<DeviceInfo> deviceInfoList = database.getAllData();
        for(DeviceInfo info : deviceInfoList) {

            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("listview_dateTime","Date: " + info.getDateTime());
            hm.put("listview_cpNumber", "CellPhone Number: " + info.getCPNumber());
            hm.put("listview_macAddress", "Mac Address: " + info.getMacAddress());
            hm.put("listview_location","Location: " + info.getLocation());
            aList.add(hm);
        }
        String[] from = { "listview_dateTime", "listview_cpNumber", "listview_macAddress", "listview_location"};
        int[] to = {R.id.listview_dateTime, R.id.listview_cpNumber , R.id.listview_macAddress , R.id.listview_location};

        SimpleAdapter simpleAdapter = new SimpleAdapter(getBaseContext(), aList, R.layout.package_listview, from, to);
        ListView androidListView = (ListView) findViewById(R.id.list_view);
        androidListView.setAdapter(simpleAdapter);
    }
}
