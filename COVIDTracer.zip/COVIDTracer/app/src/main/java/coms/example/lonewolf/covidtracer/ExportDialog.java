package coms.example.lonewolf.covidtracer;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Calendar;
import java.util.Date;

public class ExportDialog extends DialogFragment {

    String date = "";
     EditText fromDateText;
     EditText toDateText;
     DatePickerDialog fromDatePicker;
     public Button cancelBtn = null;
     public Button confirmBtn = null;
    public String textDisplay ;
    Context context;
    public ExportDialog() {
        // Required empty public constructor
    }

    public void setContext(Context context)
    {
        this.context = context;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

     public void setDisplay(String display){
         this.textDisplay = display;
     }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View main_view = inflater.inflate(R.layout.fragment_export_dialog, container, false);
        TextView result = (TextView) main_view.findViewById(R.id.tv_result);
        result.setText(this.textDisplay);

        Button confirmButton = (Button)main_view.findViewById(R.id.btn_confirm);
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, MainActivity.class);
                startActivity(intent);
            }
        });
        return main_view;
    }

}
