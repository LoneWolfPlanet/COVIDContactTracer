package coms.example.lonewolf.covidtracer;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.Transformation;
import android.view.View;
import android.content.Context;
import android.widget.Button;
import android.content.Intent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.*;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;

public class MainActivity extends AppCompatActivity {
    final Context context = this;
    public SQLiteDatabase mydatabase;
    public int REQUEST_ENABLE_BT = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startDBConnection();
        SetEventListener();
    }


    public void SetEventListener() {

        final Button scanButton = (Button)findViewById(R.id.btn_scan);

        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScanDialog scanDialog = new ScanDialog();
                scanDialog.setContext(context);
                scanDialog.show(getSupportFragmentManager(), "ScanDialog");
        }
        });
        final Button exportButton = (Button)findViewById(R.id.btn_export);
        exportButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {

                Intent export =new Intent(context, ExportActivity.class);
                startActivity(export);

            }
        });

        final Button deviceButton =(Button) findViewById(R.id.btn_devices);
        deviceButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent devices =new Intent(context, DevicesActivity.class);
                startActivity(devices);

            }
        });
    }

    @Override
    public void onBackPressed() {
    }

    public void startDBConnection()
    {
        this.mydatabase = openOrCreateDatabase("history.db",MODE_PRIVATE,null);
        DatabaseHandler.SetDatabase(this.mydatabase);
        DatabaseHandler handler  = new DatabaseHandler(this.context);

    }
}
