package coms.example.lonewolf.covidtracer;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MasterData {

     String deviceName;
     String startDateTime;

     public MasterData()
     {
         deviceName = "";
         startDateTime = "";
     }

     public void setDeviceName(String deviceName){
         this.deviceName = deviceName;
     }

     public void setStartDateTime()
     {
         Date current = Calendar.getInstance().getTime();
         SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
         String formattedDate = df.format(current);
         this.startDateTime = formattedDate;
     }

    public String getDeviceName(){
         return this.deviceName;
    }

    public String getStartDateTime(){
         return this.startDateTime;
    }
}
